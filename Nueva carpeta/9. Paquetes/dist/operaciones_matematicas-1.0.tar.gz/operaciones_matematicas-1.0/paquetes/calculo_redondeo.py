def redondear(x):
    return(round(float(x)))