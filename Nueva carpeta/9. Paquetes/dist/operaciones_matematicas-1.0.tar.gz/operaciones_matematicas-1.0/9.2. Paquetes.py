from setuptools import setup


setup(
    
    name="operaciones_matematicas",
    decription="Operaciones matematicas",
    author="dragont28",
    version="1.0",
    author_email="",
    url="",
    packages=["paquetes","paquetes.p2"]

    )